Artwork from the version-matched DoL-Lyra BESC+UCB distribution.
Sources: https://gitgud.io/Frostberg/beeesss-community-compilation-revived and https://github.com/site098/mysterious
